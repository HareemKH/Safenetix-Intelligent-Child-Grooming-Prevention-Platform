import json

MODEL_NAME = "gemini-3.5-flash-lite"

ALLOWED_INDICATORS = {
    "secrecy_request",
    "personal_information_request",
    "private_channel_migration",
    "coercion_or_pressure",
    "boundary_testing",
    "repeated_unwanted_contact",
}

def analyze_conversation(client, conversation):
    if not isinstance(conversation, list) or not conversation:
        raise ValueError("conversation must be a non-empty list")

    for item in conversation:
        if not isinstance(item, dict):
            raise ValueError("Each message must be a dictionary")
        if not isinstance(item.get("speaker"), str) or not item["speaker"].strip():
            raise ValueError("Each message needs a valid speaker")
        if not isinstance(item.get("message"), str) or not item["message"].strip():
            raise ValueError("Each message needs a valid message")

    prompt = f"""
You are the contextual safety analysis component of SafeNetix,
a child online-safety prototype for ages 5 to 15.

Analyze the ordered conversation for potential online-safety concerns.
Consider patterns across messages, not isolated keywords alone.
Ordinary friendliness, compliments, and gaming invitations alone
are not evidence of grooming. Indicators are not proof of intent.
Use cautious, non-accusatory language.

Return ONLY valid JSON with exactly these fields:
{{
  "risk_level": "low | medium | high",
  "risk_indicators": [],
  "explanation": "Brief, evidence-based explanation",
  "requires_parent_review": false
}}

Use only these indicator IDs:
- secrecy_request
- personal_information_request
- private_channel_migration
- coercion_or_pressure
- boundary_testing
- repeated_unwanted_contact

Use an empty list if none apply. Do not invent indicator IDs.
Set requires_parent_review to true when meaningful concerns warrant
parental attention. Do not claim that the conversation proves intent.

Conversation:
{json.dumps(conversation, ensure_ascii=False)}
"""

    response = client.models.generate_content(
        model=MODEL_NAME,
        contents=prompt,
        config={"response_mime_type": "application/json"},
    )

    result = json.loads(response.text)

    required_keys = {
        "risk_level",
        "risk_indicators",
        "explanation",
        "requires_parent_review",
    }

    if not isinstance(result, dict) or set(result) != required_keys:
        raise ValueError("Unexpected response schema")

    if result["risk_level"] not in {"low", "medium", "high"}:
        raise ValueError("Invalid risk_level")

    if not isinstance(result["risk_indicators"], list):
        raise ValueError("risk_indicators must be a list")

    if not all(
        isinstance(x, str) and x in ALLOWED_INDICATORS
        for x in result["risk_indicators"]
    ):
        raise ValueError("Unknown indicator ID returned")

    if not isinstance(result["explanation"], str):
        raise ValueError("explanation must be a string")

    if not isinstance(result["requires_parent_review"], bool):
        raise ValueError("requires_parent_review must be a Boolean")

    return result
