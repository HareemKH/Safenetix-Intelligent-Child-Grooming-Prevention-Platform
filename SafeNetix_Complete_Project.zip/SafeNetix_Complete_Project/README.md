# SafeNetix Complete Project Archive

This archive preserves the SafeNetix machine-learning development
artifacts and standalone API deployment package.

## Contents

- Notebooks: main FYP development notebook
- Datasets: original, cleaned and challenge datasets
- Models: final calibrated V11 model and previous model versions
- Source: contextual analyzer source and backup
- Evaluation: metrics, audit records and test artifacts
- Deployment: standalone API package and its original ZIP

## Important

1. The final V11 model is included separately under Models/Final.
2. The standalone API package is preserved under Deployment.
3. API secrets are intentionally excluded.
4. Configure GEMINI_API_KEY and SAFENETIX_API_KEY privately
   before running the deployed API.
5. This archive is a project backup, not a production server.

## Main notebook

Notebooks/final_year_project.ipynb
