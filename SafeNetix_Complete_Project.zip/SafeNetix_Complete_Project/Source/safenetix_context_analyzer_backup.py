
import json

MODEL_NAME = "gemini-3.5-flash-lite"

ALLOWED_INDICATORS = {
    "secrecy_request",
    "personal_information_request",
    "private_channel_migration",
    "coercion_or_pressure",
    "boundary_testing",
    "repeated_unwanted_contact",
}

def analyze_conversation(client, conversation):
    if not isinstance(conversation, list) or not conversation:
        raise ValueError("conversation must be a non-empty list")

    for item in conversation:
        if not isinstance(item, dict):
            raise ValueError("Each message must be a dictionary")
        if not isinstance(item.get("speaker"), str) or not item["speaker"].strip():
            raise ValueError("Each message needs a valid speaker")
        if not isinstance(item.get("message"), str) or not item["message"].strip():
            raise ValueError("Each message needs a valid message")

    prompt = f"""
You are the contextual safety analysis component of SafeNetix,
a child online-safety prototype for ages 5 to 15.

Analyze the ordered conversation for potential online-safety concerns.
Assess the whole interaction, including what happens after a request
or boundary. Do not infer intent, identity, or age beyond the evidence.

CORE PRINCIPLES
1. An indicator is a signal to interpret, not proof of grooming.
2. Do not classify ordinary friendliness, compliments, gaming invitations,
   or a single ordinary question as grooming.
3. Do not automatically assign medium or high risk because one indicator
   appears. Consider severity, repetition, combinations, and responses.
4. Respectful acceptance of a child's refusal is relevant mitigating context.
5. A respectful response does not erase a genuinely concerning earlier
   behavior, but a single request followed by acceptance is not automatically
   boundary testing.
6. Do not let a low-risk label hide a meaningful indicator. Report supported
   indicators separately from the overall risk level.
7. Use calm, non-accusatory language. Explain the specific evidence.

INDICATOR GUIDANCE
- secrecy_request: someone asks the child to hide the interaction, messages,
  or activity from a parent or trusted adult.
- personal_information_request: someone seeks identifying or sensitive
  personal information, such as a phone number, home address, school,
  location, password, or private images.
- private_channel_migration: someone proposes moving the interaction to
  another messaging service or a more private channel. This may be reported
  even when the request alone is not suspicious.
- coercion_or_pressure: someone uses threats, guilt, manipulation, or
  persistent pressure to make the child do something.
- boundary_testing: someone probes or pushes a stated boundary, especially
  by continuing after a refusal. A single request that is promptly accepted
  is generally not enough by itself.
- repeated_unwanted_contact: someone continues contacting or pursuing the
  child after clear requests to stop or repeated non-engagement.

RISK LEVEL GUIDANCE
- low: ordinary interaction, or an isolated mild indicator without additional
  concerning behavior. Use low when a boundary is respected and there is no
  meaningful pattern of pressure, secrecy, or exploitation.
- medium: a credible concern that merits attention, such as repeated boundary
  probing, persistent unwanted contact, or a combination of concerning signals
  that does not establish an acute or clearly severe pattern.
- high: strong, converging evidence of serious concern, such as coercion,
  explicit secrecy combined with requests for sensitive information, threats,
  or escalating pressure after refusal. Base the decision on actual messages.

PARENT REVIEW
Set requires_parent_review to true when the conversation contains a meaningful
pattern that a parent should assess. This will often be true for medium or high
risk. An isolated, low-risk platform-switch suggestion or a request that is
immediately and respectfully dropped does not automatically require review.
Do not treat this as a definitive accusation or a substitute for human judgment.

Return ONLY valid JSON with exactly these fields:
{{
  "risk_level": "low | medium | high",
  "risk_indicators": [],
  "explanation": "Brief, evidence-based explanation",
  "requires_parent_review": false
}}

Use only these indicator IDs:
- secrecy_request
- personal_information_request
- private_channel_migration
- coercion_or_pressure
- boundary_testing
- repeated_unwanted_contact

Use an empty list if no indicators apply. Do not invent indicator IDs.
The explanation should briefly state the relevant behavior and context.
Do not claim that the conversation proves intent.

Conversation:
{json.dumps(conversation, ensure_ascii=False)}
"""

    response = client.models.generate_content(
        model=MODEL_NAME,
        contents=prompt,
        config={"response_mime_type": "application/json"},
    )

    result = json.loads(response.text)

    required_keys = {
        "risk_level",
        "risk_indicators",
        "explanation",
        "requires_parent_review",
    }

    if not isinstance(result, dict) or set(result) != required_keys:
        raise ValueError("Unexpected response schema")

    if result["risk_level"] not in {"low", "medium", "high"}:
        raise ValueError("Invalid risk_level")

    if not isinstance(result["risk_indicators"], list):
        raise ValueError("risk_indicators must be a list")

    if not all(
        isinstance(x, str) and x in ALLOWED_INDICATORS
        for x in result["risk_indicators"]
    ):
        raise ValueError("Unknown indicator ID returned")

    if not isinstance(result["explanation"], str):
        raise ValueError("explanation must be a string")

    if not isinstance(result["requires_parent_review"], bool):
        raise ValueError("requires_parent_review must be a Boolean")

    return result
