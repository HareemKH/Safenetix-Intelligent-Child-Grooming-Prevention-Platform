
import os
import hmac
from pathlib import Path
from typing import Optional

import joblib
from fastapi import FastAPI, Depends, HTTPException
from fastapi.security import APIKeyHeader
from pydantic import BaseModel
from google import genai

import safenetix_context_analyzer

BASE_DIR = Path(__file__).resolve().parent
MODEL_PATH = BASE_DIR / "safenetix_v11_calibrated.joblib"

if not MODEL_PATH.exists():
    raise RuntimeError(f"Model artifact missing: {MODEL_PATH}")

multilingual_model = joblib.load(MODEL_PATH)

GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY")
SAFENETIX_API_KEY = os.environ.get("SAFENETIX_API_KEY")

client = (
    genai.Client(api_key=GEMINI_API_KEY)
    if GEMINI_API_KEY else None
)

api_key_header = APIKeyHeader(
    name="X-API-Key",
    auto_error=False
)

app = FastAPI(
    title="SafeNetix Unified API",
    version="1.3.0"
)

class MessageItem(BaseModel):
    speaker: str
    message: str

class ConversationRequest(BaseModel):
    conversation: list[MessageItem]

class MessagePrediction(BaseModel):
    speaker: str
    message: str
    prediction: Optional[str] = None
    probabilities: Optional[dict[str, float]] = None
    error: Optional[str] = None

class ContextualAssessment(BaseModel):
    risk_level: Optional[str] = None
    risk_indicators: Optional[list[str]] = None
    explanation: Optional[str] = None
    requires_parent_review: Optional[bool] = None
    error: Optional[str] = None

class UnifiedResponse(BaseModel):
    product: str = "SafeNetix"
    status: dict[str, str]
    message_level_predictions: list[MessagePrediction]
    contextual_assessment: ContextualAssessment

def verify_api_key(
    header_value: Optional[str] = Depends(api_key_header)
):
    expected_key = os.environ.get("SAFENETIX_API_KEY")

    if not expected_key:
        raise HTTPException(
            status_code=500,
            detail="Server API key is not configured"
        )

    if (
        not header_value
        or not hmac.compare_digest(header_value, expected_key)
    ):
        raise HTTPException(
            status_code=401,
            detail="Invalid or missing API Key"
        )

    return header_value

@app.get("/health")
def health():
    return {
        "product": "SafeNetix",
        "status": "running",
        "version": "1.3.0"
    }

@app.post(
    "/analyze",
    response_model=UnifiedResponse
)
def analyze(
    request: ConversationRequest,
    api_key: str = Depends(verify_api_key)
):
    if not request.conversation:
        raise HTTPException(
            status_code=400,
            detail="Conversation list cannot be empty"
        )

    raw_conv = [
        {
            "speaker": item.speaker,
            "message": item.message
        }
        for item in request.conversation
    ]

    # ML classification
    ml_results = []
    ml_success = True

    for item in raw_conv:
        try:
            prediction = str(
                multilingual_model.predict([item["message"]])[0]
            )

            probabilities = (
                multilingual_model.predict_proba(
                    [item["message"]]
                )[0]
            )

            probability_dict = {
                str(label): round(float(probability), 4)
                for label, probability in zip(
                    multilingual_model.classes_,
                    probabilities
                )
            }

            ml_results.append(
                MessagePrediction(
                    speaker=item["speaker"],
                    message=item["message"],
                    prediction=prediction,
                    probabilities=probability_dict
                )
            )

        except Exception as error:
            ml_success = False
            ml_results.append(
                MessagePrediction(
                    speaker=item["speaker"],
                    message=item["message"],
                    error=str(error)
                )
            )

    # Gemini contextual analysis
    gemini_success = True

    try:
        if client is None:
            raise RuntimeError(
                "GEMINI_API_KEY is not configured"
            )

        context_data = (
            safenetix_context_analyzer.analyze_conversation(
                client,
                raw_conv
            )
        )

        context_assessment = ContextualAssessment(
            risk_level=context_data.get("risk_level"),
            risk_indicators=context_data.get("risk_indicators"),
            explanation=context_data.get("explanation"),
            requires_parent_review=context_data.get(
                "requires_parent_review"
            )
        )

    except Exception as error:
        gemini_success = False
        context_assessment = ContextualAssessment(
            error=str(error)
        )

    return UnifiedResponse(
        product="SafeNetix",
        status={
            "ml_classifier": (
                "success" if ml_success else "partial_failure"
            ),
            "gemini_analyzer": (
                "success" if gemini_success else "failed"
            )
        },
        message_level_predictions=ml_results,
        contextual_assessment=context_assessment
    )
