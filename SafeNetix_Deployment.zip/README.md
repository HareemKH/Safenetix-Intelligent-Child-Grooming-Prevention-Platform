# SafeNetix Unified API

## Components
- Calibrated multilingual ML classifier (V11)
- Gemini contextual safety analyzer
- FastAPI unified endpoint
- X-API-Key authentication

## Requirements
Python 3.13.x

## Installation

Create a virtual environment:

    python -m venv .venv

Activate it, then install:

    pip install -r requirements.txt

## Configure secrets

Set these environment variables privately:

    SAFENETIX_API_KEY
    GEMINI_API_KEY

Do not commit real credentials to Git or include them in deployment archives.

## Start the server

    uvicorn app:app --host 127.0.0.1 --port 8001

For a public deployment, use an appropriate production hosting
configuration, HTTPS termination, network restrictions, and secret management.

## Endpoints

GET /health
POST /analyze

The analysis endpoint requires:

    X-API-Key: your_api_key

## Example request

    {
      "conversation": [
        {
          "speaker": "Player A",
          "message": "Chalo Roblox par Brookhaven khelte hain."
        },
        {
          "speaker": "Player B",
          "message": "Haan, mujhe bhi khelna hai."
        }
      ]
    }

## Important
- The health endpoint is intentionally public.
- The analysis endpoint requires API-key authentication.
- Gemini failure is reported separately from ML results.
- A failed Gemini assessment must not be interpreted as low risk.
- The calibrated model is loaded from the bundled Joblib artifact.
- Keep model and dependency versions compatible with the training environment.
